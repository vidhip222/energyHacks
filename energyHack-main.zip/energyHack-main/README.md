# energyHack

sample data: 
{
  "generation biomass": 447,
  "generation fossil brown coal/lignite": 329,
  "generation fossil gas": 4844,
  "generation fossil hard coal": 4821,
  "generation fossil oil": 162,
  "generation hydro pumped storage consumption": 863,
  "generation hydro run-of-river and poundage": 1051,
  "generation hydro water reservoir": 1899,
  "generation nuclear": 7096,
  "generation other": 43,
  "generation other renewable": 73,
  "generation solar": 49,
  "generation waste": 196,
  "generation wind onshore": 6378,
  "forecast solar day ahead": 17,
  "forecast wind onshore day ahead": 6436,
  "total load forecast": 26118,
  "total load actual": 25385,
  "price day ahead": 50.1
}
